/**
 * Run this class to execute Sandwich Spreadheet.
 * @author Maarten Flikkema
 */
public class Start {
	public static void main(String[] args) {
		new GUI.Window();
	}
}